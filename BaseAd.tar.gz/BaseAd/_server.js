﻿.factory('BaseTechPlanManage', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/BaseTechPlanManage', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/BaseTechPlanManage'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseTechPlanManage'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/BaseTechPlanManage'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseTechPlanManage/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseTechPlanManage/Audit'
        },
    });
}])
﻿.factory('BakePestControlTech', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/BakePestControlTech', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/BakePestControlTech'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/BakePestControlTech'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/BakePestControlTech'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/BakePestControlTech/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/BakePestControlTech/Audit'
        },
    });
}])
﻿.factory('ClimaticConditions', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/ClimaticConditions', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/ClimaticConditions'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/ClimaticConditions'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/ClimaticConditions'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/ClimaticConditions/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/ClimaticConditions/Audit'
        },
    });
}])
﻿.factory('LevelYield', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/LevelYield', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/LevelYield'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/LevelYield'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/LevelYield'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/LevelYield/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/LevelYield/Audit'
        },
    });
}])
﻿.factory('BaseEvaluation', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/BaseEvaluation', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/BaseEvaluation'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseEvaluation'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/BaseEvaluation'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseEvaluation/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseEvaluation/Audit'
        },
    });
}])
﻿.factory('TransplantPestControlTech', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/TransplantPestControlTech', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/TransplantPestControlTech'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/TransplantPestControlTech'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/TransplantPestControlTech'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/TransplantPestControlTech/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/TransplantPestControlTech/Audit'
        },
    });
}])
﻿.factory('GrowPestControlTech', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/GrowPestControlTech', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/GrowPestControlTech'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/GrowPestControlTech'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/GrowPestControlTech'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/GrowPestControlTech/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/GrowPestControlTech/Audit'
        },
    });
}])
﻿.factory('BaseInfo', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/BaseInfo', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/BaseInfo'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseInfo'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/BaseInfo'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseInfo/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/BaseInfo/Audit'
        },
    });
}])
﻿.factory('ProductionStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/ProductionStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/ProductionStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/ProductionStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/ProductionStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/ProductionStatus/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/ProductionStatus/Audit'
        },
    });
}])
﻿.factory('BakePeriodStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/BakePeriodStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/BakePeriodStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/BakePeriodStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/BakePeriodStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/BakePeriodStatus/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/BakePeriodStatus/Audit'
        },
    });
}])
﻿.factory('NurseryPestControl', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/NurseryPestControl', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/NurseryPestControl'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/NurseryPestControl'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/NurseryPestControl'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/NurseryPestControl/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/NurseryPestControl/Audit'
        },
    });
}])
﻿.factory('TransplantPeriodInfo', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/TransplantPeriodInfo', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/TransplantPeriodInfo'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/TransplantPeriodInfo'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/TransplantPeriodInfo'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/TransplantPeriodInfo/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/TransplantPeriodInfo/Audit'
        },
    });
}])
﻿.factory('GrowPeriodStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/GrowPeriodStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/GrowPeriodStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/GrowPeriodStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/GrowPeriodStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/GrowPeriodStatus/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/GrowPeriodStatus/Audit'
        },
    });
}])
﻿.factory('SeedbedPeriodStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/BaseAd/SeedbedPeriodStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/BaseAd/SeedbedPeriodStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/BaseAd/SeedbedPeriodStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/BaseAd/SeedbedPeriodStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/BaseAd/SeedbedPeriodStatus/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/BaseAd/SeedbedPeriodStatus/Audit'
        },
    });
}])