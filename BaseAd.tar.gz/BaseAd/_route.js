﻿.state('app.BaseAd.ProductionStatus', {
   url: '/ProductionStatus',
   title: 'ProductionStatus',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.ProductionStatus.list', {
    url: '/list',
    controller: 'ProductionStatusController',
    templateUrl: helper.basepath('BaseAd/ProductionStatus.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.ProductionStatus.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/ProductionStatusedit.html'),
    controller: 'ProductionStatusEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.SeedbedPeriodStatus', {
   url: '/SeedbedPeriodStatus',
   title: 'SeedbedPeriodStatus',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.SeedbedPeriodStatus.list', {
    url: '/list',
    controller: 'SeedbedPeriodStatusController',
    templateUrl: helper.basepath('BaseAd/SeedbedPeriodStatus.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.SeedbedPeriodStatus.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/SeedbedPeriodStatusedit.html'),
    controller: 'SeedbedPeriodStatusEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.BaseInfo', {
   url: '/BaseInfo',
   title: 'BaseInfo',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.BaseInfo.list', {
    url: '/list',
    controller: 'BaseInfoController',
    templateUrl: helper.basepath('BaseAd/BaseInfo.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.BaseInfo.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/BaseInfoedit.html'),
    controller: 'BaseInfoEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.BakePestControlTech', {
   url: '/BakePestControlTech',
   title: 'BakePestControlTech',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.BakePestControlTech.list', {
    url: '/list',
    controller: 'BakePestControlTechController',
    templateUrl: helper.basepath('BaseAd/BakePestControlTech.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.BakePestControlTech.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/BakePestControlTechedit.html'),
    controller: 'BakePestControlTechEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.GrowPestControlTech', {
   url: '/GrowPestControlTech',
   title: 'GrowPestControlTech',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.GrowPestControlTech.list', {
    url: '/list',
    controller: 'GrowPestControlTechController',
    templateUrl: helper.basepath('BaseAd/GrowPestControlTech.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.GrowPestControlTech.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/GrowPestControlTechedit.html'),
    controller: 'GrowPestControlTechEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.LevelYield', {
   url: '/LevelYield',
   title: 'LevelYield',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.LevelYield.list', {
    url: '/list',
    controller: 'LevelYieldController',
    templateUrl: helper.basepath('BaseAd/LevelYield.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.LevelYield.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/LevelYieldedit.html'),
    controller: 'LevelYieldEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.GrowPeriodStatus', {
   url: '/GrowPeriodStatus',
   title: 'GrowPeriodStatus',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.GrowPeriodStatus.list', {
    url: '/list',
    controller: 'GrowPeriodStatusController',
    templateUrl: helper.basepath('BaseAd/GrowPeriodStatus.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.GrowPeriodStatus.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/GrowPeriodStatusedit.html'),
    controller: 'GrowPeriodStatusEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.TransplantPeriodInfo', {
   url: '/TransplantPeriodInfo',
   title: 'TransplantPeriodInfo',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.TransplantPeriodInfo.list', {
    url: '/list',
    controller: 'TransplantPeriodInfoController',
    templateUrl: helper.basepath('BaseAd/TransplantPeriodInfo.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.TransplantPeriodInfo.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/TransplantPeriodInfoedit.html'),
    controller: 'TransplantPeriodInfoEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.NurseryPestControl', {
   url: '/NurseryPestControl',
   title: 'NurseryPestControl',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.NurseryPestControl.list', {
    url: '/list',
    controller: 'NurseryPestControlController',
    templateUrl: helper.basepath('BaseAd/NurseryPestControl.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.NurseryPestControl.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/NurseryPestControledit.html'),
    controller: 'NurseryPestControlEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.ClimaticConditions', {
   url: '/ClimaticConditions',
   title: 'ClimaticConditions',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.ClimaticConditions.list', {
    url: '/list',
    controller: 'ClimaticConditionsController',
    templateUrl: helper.basepath('BaseAd/ClimaticConditions.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.ClimaticConditions.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/ClimaticConditionsedit.html'),
    controller: 'ClimaticConditionsEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.BaseEvaluation', {
   url: '/BaseEvaluation',
   title: 'BaseEvaluation',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.BaseEvaluation.list', {
    url: '/list',
    controller: 'BaseEvaluationController',
    templateUrl: helper.basepath('BaseAd/BaseEvaluation.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.BaseEvaluation.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/BaseEvaluationedit.html'),
    controller: 'BaseEvaluationEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.BaseTechPlanManage', {
   url: '/BaseTechPlanManage',
   title: 'BaseTechPlanManage',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.BaseTechPlanManage.list', {
    url: '/list',
    controller: 'BaseTechPlanManageController',
    templateUrl: helper.basepath('BaseAd/BaseTechPlanManage.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.BaseTechPlanManage.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/BaseTechPlanManageedit.html'),
    controller: 'BaseTechPlanManageEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.BakePeriodStatus', {
   url: '/BakePeriodStatus',
   title: 'BakePeriodStatus',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.BakePeriodStatus.list', {
    url: '/list',
    controller: 'BakePeriodStatusController',
    templateUrl: helper.basepath('BaseAd/BakePeriodStatus.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.BakePeriodStatus.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/BakePeriodStatusedit.html'),
    controller: 'BakePeriodStatusEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.BaseAd.TransplantPestControlTech', {
   url: '/TransplantPestControlTech',
   title: 'TransplantPestControlTech',
   abstract: true,
   templateUrl: helper.basepath('BaseAd/home.html')
})
.state('app.BaseAd.TransplantPestControlTech.list', {
    url: '/list',
    controller: 'TransplantPestControlTechController',
    templateUrl: helper.basepath('BaseAd/TransplantPestControlTech.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.BaseAd.TransplantPestControlTech.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('BaseAd/TransplantPestControlTechedit.html'),
    controller: 'TransplantPestControlTechEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})