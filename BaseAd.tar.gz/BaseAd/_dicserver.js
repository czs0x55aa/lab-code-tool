﻿.factory('NurseryPestControl', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/NurseryPestControl', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/NurseryPestControl'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/NurseryPestControl'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/NurseryPestControl'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/NurseryPestControl/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/NurseryPestControl/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/NurseryPestControl/deleteDetails' 
        },
    });
 }])
﻿.factory('BaseEvaluation', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/BaseEvaluation', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/BaseEvaluation'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/BaseEvaluation'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/BaseEvaluation'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/BaseEvaluation/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/BaseEvaluation/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/BaseEvaluation/deleteDetails' 
        },
    });
 }])
﻿.factory('LevelYield', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/LevelYield', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/LevelYield'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/LevelYield'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/LevelYield'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/LevelYield/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/LevelYield/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/LevelYield/deleteDetails' 
        },
    });
 }])
﻿.factory('TransplantPestControlTech', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/TransplantPestControlTech', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/TransplantPestControlTech'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/TransplantPestControlTech'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/TransplantPestControlTech'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/TransplantPestControlTech/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/TransplantPestControlTech/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/TransplantPestControlTech/deleteDetails' 
        },
    });
 }])
﻿.factory('BaseTechPlanManage', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/BaseTechPlanManage', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/BaseTechPlanManage'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/BaseTechPlanManage'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/BaseTechPlanManage'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/BaseTechPlanManage/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/BaseTechPlanManage/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/BaseTechPlanManage/deleteDetails' 
        },
    });
 }])
﻿.factory('BakePestControlTech', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/BakePestControlTech', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/BakePestControlTech'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/BakePestControlTech'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/BakePestControlTech'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/BakePestControlTech/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/BakePestControlTech/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/BakePestControlTech/deleteDetails' 
        },
    });
 }])
﻿.factory('SeedbedPeriodStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/SeedbedPeriodStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/SeedbedPeriodStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/SeedbedPeriodStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/SeedbedPeriodStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/SeedbedPeriodStatus/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/SeedbedPeriodStatus/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/SeedbedPeriodStatus/deleteDetails' 
        },
    });
 }])
﻿.factory('GrowPeriodStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/GrowPeriodStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/GrowPeriodStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/GrowPeriodStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/GrowPeriodStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/GrowPeriodStatus/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/GrowPeriodStatus/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/GrowPeriodStatus/deleteDetails' 
        },
    });
 }])
﻿.factory('BakePeriodStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/BakePeriodStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/BakePeriodStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/BakePeriodStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/BakePeriodStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/BakePeriodStatus/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/BakePeriodStatus/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/BakePeriodStatus/deleteDetails' 
        },
    });
 }])
﻿.factory('ClimaticConditions', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/ClimaticConditions', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/ClimaticConditions'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/ClimaticConditions'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/ClimaticConditions'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/ClimaticConditions/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/ClimaticConditions/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/ClimaticConditions/deleteDetails' 
        },
    });
 }])
﻿.factory('BaseInfo', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/BaseInfo', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/BaseInfo'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/BaseInfo'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/BaseInfo'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/BaseInfo/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/BaseInfo/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/BaseInfo/deleteDetails' 
        },
    });
 }])
﻿.factory('ProductionStatus', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/ProductionStatus', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/ProductionStatus'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/ProductionStatus'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/ProductionStatus'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/ProductionStatus/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/ProductionStatus/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/ProductionStatus/deleteDetails' 
        },
    });
 }])
﻿.factory('TransplantPeriodInfo', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/TransplantPeriodInfo', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/TransplantPeriodInfo'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/TransplantPeriodInfo'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/TransplantPeriodInfo'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/TransplantPeriodInfo/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/TransplantPeriodInfo/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/TransplantPeriodInfo/deleteDetails' 
        },
    });
 }])
﻿.factory('GrowPestControlTech', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/GrowPestControlTech', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/GrowPestControlTech'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/GrowPestControlTech'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/GrowPestControlTech'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/GrowPestControlTech/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/GrowPestControlTech/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/GrowPestControlTech/deleteDetails' 
        },
    });
 }])