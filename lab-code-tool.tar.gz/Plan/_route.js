﻿.state('app.Plan.AllocateTransport', {
   url: '/AllocateTransport',
   title: 'AllocateTransport',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.AllocateTransport.list', {
    url: '/list',
    controller: 'AllocateTransportController',
    templateUrl: helper.basepath('Plan/AllocateTransport.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.AllocateTransport.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/AllocateTransportedit.html'),
    controller: 'AllocateTransportEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Plan.ContractSettlement', {
   url: '/ContractSettlement',
   title: 'ContractSettlement',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.ContractSettlement.list', {
    url: '/list',
    controller: 'ContractSettlementController',
    templateUrl: helper.basepath('Plan/ContractSettlement.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.ContractSettlement.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/ContractSettlementedit.html'),
    controller: 'ContractSettlementEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Plan.RealTimeContract', {
   url: '/RealTimeContract',
   title: 'RealTimeContract',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.RealTimeContract.list', {
    url: '/list',
    controller: 'RealTimeContractController',
    templateUrl: helper.basepath('Plan/RealTimeContract.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.RealTimeContract.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/RealTimeContractedit.html'),
    controller: 'RealTimeContractEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Plan.AnnualProtocol', {
   url: '/AnnualProtocol',
   title: 'AnnualProtocol',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.AnnualProtocol.list', {
    url: '/list',
    controller: 'AnnualProtocolController',
    templateUrl: helper.basepath('Plan/AnnualProtocol.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.AnnualProtocol.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/AnnualProtocoledit.html'),
    controller: 'AnnualProtocolEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Plan.PaperContractProtocol', {
   url: '/PaperContractProtocol',
   title: 'PaperContractProtocol',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.PaperContractProtocol.list', {
    url: '/list',
    controller: 'PaperContractProtocolController',
    templateUrl: helper.basepath('Plan/PaperContractProtocol.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.PaperContractProtocol.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/PaperContractProtocoledit.html'),
    controller: 'PaperContractProtocolEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Plan.ContractProtocolType', {
   url: '/ContractProtocolType',
   title: 'ContractProtocolType',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.ContractProtocolType.list', {
    url: '/list',
    controller: 'ContractProtocolTypeController',
    templateUrl: helper.basepath('Plan/ContractProtocolType.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.ContractProtocolType.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/ContractProtocolTypeedit.html'),
    controller: 'ContractProtocolTypeEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Plan.ProcessContract', {
   url: '/ProcessContract',
   title: 'ProcessContract',
   abstract: true,
   templateUrl: helper.basepath('Plan/home.html')
})
.state('app.Plan.ProcessContract.list', {
    url: '/list',
    controller: 'ProcessContractController',
    templateUrl: helper.basepath('Plan/ProcessContract.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Plan.ProcessContract.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Plan/ProcessContractedit.html'),
    controller: 'ProcessContractEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})