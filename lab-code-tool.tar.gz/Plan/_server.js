﻿.factory('AnnualProtocol', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/AnnualProtocol', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/AnnualProtocol'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/AnnualProtocol'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/AnnualProtocol'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/AnnualProtocol/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/AnnualProtocol/Audit'
        },
    });
}])
﻿.factory('RealTimeContract', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/RealTimeContract', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/RealTimeContract'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/RealTimeContract'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/RealTimeContract'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/RealTimeContract/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/RealTimeContract/Audit'
        },
    });
}])
﻿.factory('ProcessContract', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/ProcessContract', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/ProcessContract'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/ProcessContract'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/ProcessContract'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/ProcessContract/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/ProcessContract/Audit'
        },
    });
}])
﻿.factory('PaperContractProtocol', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/PaperContractProtocol', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/PaperContractProtocol'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/PaperContractProtocol'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/PaperContractProtocol'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/PaperContractProtocol/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/PaperContractProtocol/Audit'
        },
    });
}])
﻿.factory('ContractSettlement', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/ContractSettlement', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/ContractSettlement'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/ContractSettlement'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/ContractSettlement'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/ContractSettlement/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/ContractSettlement/Audit'
        },
    });
}])
﻿.factory('AllocateTransport', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/AllocateTransport', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/AllocateTransport'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/AllocateTransport'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/AllocateTransport'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/AllocateTransport/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/AllocateTransport/Audit'
        },
    });
}])
﻿.factory('ContractProtocolType', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Plan/ContractProtocolType', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Plan/ContractProtocolType'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Plan/ContractProtocolType'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Plan/ContractProtocolType'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Plan/ContractProtocolType/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Plan/ContractProtocolType/Audit'
        },
    });
}])