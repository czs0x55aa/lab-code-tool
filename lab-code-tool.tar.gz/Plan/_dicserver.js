﻿.factory('PaperContractProtocol', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/PaperContractProtocol', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/PaperContractProtocol'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/PaperContractProtocol'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/PaperContractProtocol'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/PaperContractProtocol/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/PaperContractProtocol/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/PaperContractProtocol/deleteDetails' 
        },
    });
 }])
﻿.factory('AnnualProtocol', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/AnnualProtocol', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/AnnualProtocol'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/AnnualProtocol'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/AnnualProtocol'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/AnnualProtocol/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/AnnualProtocol/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/AnnualProtocol/deleteDetails' 
        },
    });
 }])
﻿.factory('AllocateTransport', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/AllocateTransport', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/AllocateTransport'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/AllocateTransport'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/AllocateTransport'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/AllocateTransport/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/AllocateTransport/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/AllocateTransport/deleteDetails' 
        },
    });
 }])
﻿.factory('ContractProtocolType', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/ContractProtocolType', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/ContractProtocolType'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/ContractProtocolType'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/ContractProtocolType'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/ContractProtocolType/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/ContractProtocolType/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/ContractProtocolType/deleteDetails' 
        },
    });
 }])
﻿.factory('ContractSettlement', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/ContractSettlement', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/ContractSettlement'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/ContractSettlement'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/ContractSettlement'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/ContractSettlement/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/ContractSettlement/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/ContractSettlement/deleteDetails' 
        },
    });
 }])
﻿.factory('RealTimeContract', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/RealTimeContract', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/RealTimeContract'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/RealTimeContract'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/RealTimeContract'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/RealTimeContract/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/RealTimeContract/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/RealTimeContract/deleteDetails' 
        },
    });
 }])
﻿.factory('ProcessContract', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/ProcessContract', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/ProcessContract'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/ProcessContract'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/ProcessContract'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/ProcessContract/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/ProcessContract/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/ProcessContract/deleteDetails' 
        },
    });
 }])