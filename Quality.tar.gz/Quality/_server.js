﻿.factory('CaboStockQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/CaboStockQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/CaboStockQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/CaboStockQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/CaboStockQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/CaboStockQuality/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/CaboStockQuality/Audit'
        },
    });
}])
﻿.factory('SampleSmokeEvaluation', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/SampleSmokeEvaluation', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/SampleSmokeEvaluation'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/SampleSmokeEvaluation'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/SampleSmokeEvaluation'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/SampleSmokeEvaluation/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/SampleSmokeEvaluation/Audit'
        },
    });
}])
﻿.factory('TobaccoStockQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/TobaccoStockQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/TobaccoStockQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/TobaccoStockQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/TobaccoStockQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/TobaccoStockQuality/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/TobaccoStockQuality/Audit'
        },
    });
}])
﻿.factory('TobaccoIndustryQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/TobaccoIndustryQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/TobaccoIndustryQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/TobaccoIndustryQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/TobaccoIndustryQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/TobaccoIndustryQuality/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/TobaccoIndustryQuality/Audit'
        },
    });
}])
﻿.factory('CaboInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/CaboInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/CaboInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/CaboInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/CaboInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/CaboInQualityTest/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/CaboInQualityTest/Audit'
        },
    });
}])
﻿.factory('SliceColorInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/SliceColorInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/SliceColorInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/SliceColorInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/SliceColorInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/SliceColorInQualityTest/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/SliceColorInQualityTest/Audit'
        },
    });
}])
﻿.factory('CaboIndustryQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/CaboIndustryQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/CaboIndustryQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/CaboIndustryQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/CaboIndustryQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/CaboIndustryQuality/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/CaboIndustryQuality/Audit'
        },
    });
}])
﻿.factory('StripsInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/StripsInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/StripsInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/StripsInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/StripsInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/StripsInQualityTest/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/StripsInQualityTest/Audit'
        },
    });
}])
﻿.factory('QualityInspection', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/QualityInspection', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/QualityInspection'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/QualityInspection'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/QualityInspection'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/QualityInspection/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/QualityInspection/Audit'
        },
    });
}])
﻿.factory('StripsStockQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/StripsStockQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/StripsStockQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/StripsStockQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/StripsStockQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/StripsStockQuality/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/StripsStockQuality/Audit'
        },
    });
}])
﻿.factory('StripsIndustryQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/StripsIndustryQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/StripsIndustryQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/StripsIndustryQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/StripsIndustryQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/StripsIndustryQuality/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/StripsIndustryQuality/Audit'
        },
    });
}])
﻿.factory('SliceInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Quality/SliceInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Quality/SliceInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Quality/SliceInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Quality/SliceInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Quality/SliceInQualityTest/deletes'
        },
        Audit: {
            method: 'Post',
            url: host + '/api/Quality/SliceInQualityTest/Audit'
        },
    });
}])