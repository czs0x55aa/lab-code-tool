﻿.state('app.Quality.SampleSmokeEvaluation', {
   url: '/SampleSmokeEvaluation',
   title: 'SampleSmokeEvaluation',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.SampleSmokeEvaluation.list', {
    url: '/list',
    controller: 'SampleSmokeEvaluationController',
    templateUrl: helper.basepath('Quality/SampleSmokeEvaluation.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.SampleSmokeEvaluation.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/SampleSmokeEvaluationedit.html'),
    controller: 'SampleSmokeEvaluationEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.StripsStockQuality', {
   url: '/StripsStockQuality',
   title: 'StripsStockQuality',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.StripsStockQuality.list', {
    url: '/list',
    controller: 'StripsStockQualityController',
    templateUrl: helper.basepath('Quality/StripsStockQuality.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.StripsStockQuality.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/StripsStockQualityedit.html'),
    controller: 'StripsStockQualityEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.QualityInspection', {
   url: '/QualityInspection',
   title: 'QualityInspection',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.QualityInspection.list', {
    url: '/list',
    controller: 'QualityInspectionController',
    templateUrl: helper.basepath('Quality/QualityInspection.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.QualityInspection.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/QualityInspectionedit.html'),
    controller: 'QualityInspectionEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.SliceColorInQualityTest', {
   url: '/SliceColorInQualityTest',
   title: 'SliceColorInQualityTest',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.SliceColorInQualityTest.list', {
    url: '/list',
    controller: 'SliceColorInQualityTestController',
    templateUrl: helper.basepath('Quality/SliceColorInQualityTest.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.SliceColorInQualityTest.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/SliceColorInQualityTestedit.html'),
    controller: 'SliceColorInQualityTestEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.CaboIndustryQuality', {
   url: '/CaboIndustryQuality',
   title: 'CaboIndustryQuality',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.CaboIndustryQuality.list', {
    url: '/list',
    controller: 'CaboIndustryQualityController',
    templateUrl: helper.basepath('Quality/CaboIndustryQuality.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.CaboIndustryQuality.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/CaboIndustryQualityedit.html'),
    controller: 'CaboIndustryQualityEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.StripsIndustryQuality', {
   url: '/StripsIndustryQuality',
   title: 'StripsIndustryQuality',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.StripsIndustryQuality.list', {
    url: '/list',
    controller: 'StripsIndustryQualityController',
    templateUrl: helper.basepath('Quality/StripsIndustryQuality.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.StripsIndustryQuality.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/StripsIndustryQualityedit.html'),
    controller: 'StripsIndustryQualityEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.CaboInQualityTest', {
   url: '/CaboInQualityTest',
   title: 'CaboInQualityTest',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.CaboInQualityTest.list', {
    url: '/list',
    controller: 'CaboInQualityTestController',
    templateUrl: helper.basepath('Quality/CaboInQualityTest.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.CaboInQualityTest.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/CaboInQualityTestedit.html'),
    controller: 'CaboInQualityTestEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.SliceInQualityTest', {
   url: '/SliceInQualityTest',
   title: 'SliceInQualityTest',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.SliceInQualityTest.list', {
    url: '/list',
    controller: 'SliceInQualityTestController',
    templateUrl: helper.basepath('Quality/SliceInQualityTest.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.SliceInQualityTest.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/SliceInQualityTestedit.html'),
    controller: 'SliceInQualityTestEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.CaboStockQuality', {
   url: '/CaboStockQuality',
   title: 'CaboStockQuality',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.CaboStockQuality.list', {
    url: '/list',
    controller: 'CaboStockQualityController',
    templateUrl: helper.basepath('Quality/CaboStockQuality.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.CaboStockQuality.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/CaboStockQualityedit.html'),
    controller: 'CaboStockQualityEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.StripsInQualityTest', {
   url: '/StripsInQualityTest',
   title: 'StripsInQualityTest',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.StripsInQualityTest.list', {
    url: '/list',
    controller: 'StripsInQualityTestController',
    templateUrl: helper.basepath('Quality/StripsInQualityTest.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.StripsInQualityTest.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/StripsInQualityTestedit.html'),
    controller: 'StripsInQualityTestEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.TobaccoIndustryQuality', {
   url: '/TobaccoIndustryQuality',
   title: 'TobaccoIndustryQuality',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.TobaccoIndustryQuality.list', {
    url: '/list',
    controller: 'TobaccoIndustryQualityController',
    templateUrl: helper.basepath('Quality/TobaccoIndustryQuality.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.TobaccoIndustryQuality.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/TobaccoIndustryQualityedit.html'),
    controller: 'TobaccoIndustryQualityEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})
﻿.state('app.Quality.TobaccoStockQuality', {
   url: '/TobaccoStockQuality',
   title: 'TobaccoStockQuality',
   abstract: true,
   templateUrl: helper.basepath('Quality/home.html')
})
.state('app.Quality.TobaccoStockQuality.list', {
    url: '/list',
    controller: 'TobaccoStockQualityController',
    templateUrl: helper.basepath('Quality/TobaccoStockQuality.html'),
    resolve: helper.resolveFor('toaster', 'ngDialog')
})
.state('app.Quality.TobaccoStockQuality.edit', {
    url: '/edit?ID',
    templateUrl: helper.basepath('Quality/TobaccoStockQualityedit.html'),
    controller: 'TobaccoStockQualityEditController',
    resolve: helper.resolveFor('toaster', 'ngDialog', 'xeditable')
})