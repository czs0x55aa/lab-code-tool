﻿.factory('CaboInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/CaboInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/CaboInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/CaboInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/CaboInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/CaboInQualityTest/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/CaboInQualityTest/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/CaboInQualityTest/deleteDetails' 
        },
    });
 }])
﻿.factory('CaboIndustryQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/CaboIndustryQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/CaboIndustryQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/CaboIndustryQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/CaboIndustryQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/CaboIndustryQuality/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/CaboIndustryQuality/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/CaboIndustryQuality/deleteDetails' 
        },
    });
 }])
﻿.factory('StripsInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/StripsInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/StripsInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/StripsInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/StripsInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/StripsInQualityTest/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/StripsInQualityTest/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/StripsInQualityTest/deleteDetails' 
        },
    });
 }])
﻿.factory('TobaccoIndustryQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/TobaccoIndustryQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/TobaccoIndustryQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/TobaccoIndustryQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/TobaccoIndustryQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/TobaccoIndustryQuality/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/TobaccoIndustryQuality/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/TobaccoIndustryQuality/deleteDetails' 
        },
    });
 }])
﻿.factory('TobaccoStockQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/TobaccoStockQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/TobaccoStockQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/TobaccoStockQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/TobaccoStockQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/TobaccoStockQuality/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/TobaccoStockQuality/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/TobaccoStockQuality/deleteDetails' 
        },
    });
 }])
﻿.factory('QualityInspection', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/QualityInspection', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/QualityInspection'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/QualityInspection'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/QualityInspection'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/QualityInspection/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/QualityInspection/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/QualityInspection/deleteDetails' 
        },
    });
 }])
﻿.factory('StripsStockQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/StripsStockQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/StripsStockQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/StripsStockQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/StripsStockQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/StripsStockQuality/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/StripsStockQuality/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/StripsStockQuality/deleteDetails' 
        },
    });
 }])
﻿.factory('StripsIndustryQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/StripsIndustryQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/StripsIndustryQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/StripsIndustryQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/StripsIndustryQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/StripsIndustryQuality/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/StripsIndustryQuality/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/StripsIndustryQuality/deleteDetails' 
        },
    });
 }])
﻿.factory('SliceInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/SliceInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/SliceInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/SliceInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/SliceInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/SliceInQualityTest/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/SliceInQualityTest/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/SliceInQualityTest/deleteDetails' 
        },
    });
 }])
﻿.factory('SliceColorInQualityTest', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/SliceColorInQualityTest', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/SliceColorInQualityTest'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/SliceColorInQualityTest'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/SliceColorInQualityTest'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/SliceColorInQualityTest/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/SliceColorInQualityTest/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/SliceColorInQualityTest/deleteDetails' 
        },
    });
 }])
﻿.factory('CaboStockQuality', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/CaboStockQuality', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/CaboStockQuality'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/CaboStockQuality'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/CaboStockQuality'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/CaboStockQuality/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/CaboStockQuality/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/CaboStockQuality/deleteDetails' 
        },
    });
 }])
﻿.factory('SampleSmokeEvaluation', ['$q', '$resource', function ($q, $resource) {
    return $resource(host + '/api/Dic/SampleSmokeEvaluation', {}, {
        Get: {
            method: 'GET',
            url: host + '/api/Dic/SampleSmokeEvaluation'
        },
        Post: {
            method: 'Post',
            url: host + '/api/Dic/SampleSmokeEvaluation'
        },
        Delete: {
            method: 'Delete',
            url: host + '/api/Dic/SampleSmokeEvaluation'
        },
        Deletes: {
            method: 'Post',
            url: host + '/api/Dic/SampleSmokeEvaluation/deletes'
        },
        DeleteDetail: {
            method: 'Delete',
            url: host + '/api/Dic/SampleSmokeEvaluation/deleteDetail'
        },
        DeleteDetails: {
            method: 'Post',
            url: host + '/api/Dic/SampleSmokeEvaluation/deleteDetails' 
        },
    });
 }])